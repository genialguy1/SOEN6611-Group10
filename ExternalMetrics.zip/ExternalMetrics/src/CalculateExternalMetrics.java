import java.util.Scanner;

import com.sun.corba.se.impl.protocol.giopmsgheaders.Message;

public class CalculateExternalMetrics {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int iChoice = 0;
		double abstraction = 0;
		double encapsulation = 0;
		double composition = 0;
		double inheritance = 0;
		double polymorphism = 0;
		double coupling = 0;
		double cohesion = 0;
		double messaging = 0;
		double designsize = 0;
		double total;

		for (;;) {
			System.out.println("External Metrics Calculation");
			System.out.println("Enter a choice");
			System.out.println("1. Effectiveness");
			System.out.println("2. Reusability");
			System.out.println("Enter Your choice");

			Scanner in = new Scanner(System.in);
			iChoice = in.nextInt();

			if (iChoice == 1) {

				System.out.println("Abstractness value:");
				abstraction = in.nextDouble();
				System.out.println("encapsulation value:");
				encapsulation = in.nextDouble();
				System.out.println("composition value:");
				composition = in.nextDouble();
				System.out.println("Inheritance value:");
				inheritance = in.nextDouble();
				System.out.println("polymorphism value:");
				polymorphism = in.nextDouble();

				total = 0.2 * abstraction + 0.2 * encapsulation + 0.2
						* composition + 0.2 * inheritance + 0.2 * polymorphism;

				System.out.println("Effectiveness value: " + total);

			} else if (iChoice == 2) {

				System.out.println("Coupling value:");
				coupling = in.nextDouble();
				System.out.println("cohesion value:");
				cohesion = in.nextDouble();
				System.out.println("Messaging value:");
				messaging = in.nextDouble();
				System.out.println("Design size value:");
				designsize = in.nextDouble();

				total = -0.25 * coupling + 0.25 * cohesion + 0.5 * messaging
						+ 0.5 * designsize;

				System.out.println("Reusability value :" + total);

			} else {
				System.out.println("Select the given choice");
			}

		}
	}
}
