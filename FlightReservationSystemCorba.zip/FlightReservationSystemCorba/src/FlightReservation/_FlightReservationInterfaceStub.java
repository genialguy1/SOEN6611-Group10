package FlightReservation;

/**
 * Interface definition: FlightReservationInterface.
 * 
 * @author OpenORB Compiler
 */
public class _FlightReservationInterfaceStub extends org.omg.CORBA.portable.ObjectImpl
        implements FlightReservationInterface
{
    static final String[] _ids_list =
    {
        "IDL:FlightReservation/FlightReservationInterface:1.0"
    };

    public String[] _ids()
    {
     return _ids_list;
    }

    private final static Class _opsClass = FlightReservation.FlightReservationInterfaceOperations.class;

    /**
     * Operation fnBookFlight
     */
    public String fnBookFlight(String strCustomerFirstName, String strCustomerLastName, String strCustomerAddress, String dCustomerPhoneNumber, String strFlightSource, String strFlightDestination, String strFlightDate, String strFlightClass)
    {
        while(true)
        {
            if (!this._is_local())
            {
                org.omg.CORBA.portable.InputStream _input = null;
                try
                {
                    org.omg.CORBA.portable.OutputStream _output = this._request("fnBookFlight",true);
                    _output.write_string(strCustomerFirstName);
                    _output.write_string(strCustomerLastName);
                    _output.write_string(strCustomerAddress);
                    _output.write_string(dCustomerPhoneNumber);
                    _output.write_string(strFlightSource);
                    _output.write_string(strFlightDestination);
                    _output.write_string(strFlightDate);
                    _output.write_string(strFlightClass);
                    _input = this._invoke(_output);
                    String _arg_ret = _input.read_string();
                    return _arg_ret;
                }
                catch(org.omg.CORBA.portable.RemarshalException _exception)
                {
                    continue;
                }
                catch(org.omg.CORBA.portable.ApplicationException _exception)
                {
                    String _exception_id = _exception.getId();
                    throw new org.omg.CORBA.UNKNOWN("Unexpected User Exception: "+ _exception_id);
                }
                finally
                {
                    this._releaseReply(_input);
                }
            }
            else
            {
                org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke("fnBookFlight",_opsClass);
                if (_so == null)
                   continue;
                FlightReservation.FlightReservationInterfaceOperations _self = (FlightReservation.FlightReservationInterfaceOperations) _so.servant;
                try
                {
                    return _self.fnBookFlight( strCustomerFirstName,  strCustomerLastName,  strCustomerAddress,  dCustomerPhoneNumber,  strFlightSource,  strFlightDestination,  strFlightDate,  strFlightClass);
                }
                finally
                {
                    _servant_postinvoke(_so);
                }
            }
        }
    }

    /**
     * Operation fnGetBookedFlightCount
     */
    public String fnGetBookedFlightCount(String Location)
    {
        while(true)
        {
            if (!this._is_local())
            {
                org.omg.CORBA.portable.InputStream _input = null;
                try
                {
                    org.omg.CORBA.portable.OutputStream _output = this._request("fnGetBookedFlightCount",true);
                    _output.write_string(Location);
                    _input = this._invoke(_output);
                    String _arg_ret = _input.read_string();
                    return _arg_ret;
                }
                catch(org.omg.CORBA.portable.RemarshalException _exception)
                {
                    continue;
                }
                catch(org.omg.CORBA.portable.ApplicationException _exception)
                {
                    String _exception_id = _exception.getId();
                    throw new org.omg.CORBA.UNKNOWN("Unexpected User Exception: "+ _exception_id);
                }
                finally
                {
                    this._releaseReply(_input);
                }
            }
            else
            {
                org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke("fnGetBookedFlightCount",_opsClass);
                if (_so == null)
                   continue;
                FlightReservation.FlightReservationInterfaceOperations _self = (FlightReservation.FlightReservationInterfaceOperations) _so.servant;
                try
                {
                    return _self.fnGetBookedFlightCount( Location);
                }
                finally
                {
                    _servant_postinvoke(_so);
                }
            }
        }
    }

    /**
     * Operation fnEditFlightRecord
     */
    public String fnEditFlightRecord(String strManagerId, String strFlightId, String strFieldName, String strValue, String strOption)
    {
        while(true)
        {
            if (!this._is_local())
            {
                org.omg.CORBA.portable.InputStream _input = null;
                try
                {
                    org.omg.CORBA.portable.OutputStream _output = this._request("fnEditFlightRecord",true);
                    _output.write_string(strManagerId);
                    _output.write_string(strFlightId);
                    _output.write_string(strFieldName);
                    _output.write_string(strValue);
                    _output.write_string(strOption);
                    _input = this._invoke(_output);
                    String _arg_ret = _input.read_string();
                    return _arg_ret;
                }
                catch(org.omg.CORBA.portable.RemarshalException _exception)
                {
                    continue;
                }
                catch(org.omg.CORBA.portable.ApplicationException _exception)
                {
                    String _exception_id = _exception.getId();
                    throw new org.omg.CORBA.UNKNOWN("Unexpected User Exception: "+ _exception_id);
                }
                finally
                {
                    this._releaseReply(_input);
                }
            }
            else
            {
                org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke("fnEditFlightRecord",_opsClass);
                if (_so == null)
                   continue;
                FlightReservation.FlightReservationInterfaceOperations _self = (FlightReservation.FlightReservationInterfaceOperations) _so.servant;
                try
                {
                    return _self.fnEditFlightRecord( strManagerId,  strFlightId,  strFieldName,  strValue,  strOption);
                }
                finally
                {
                    _servant_postinvoke(_so);
                }
            }
        }
    }

    /**
     * Operation fnTransferFlightDetails
     */
    public String fnTransferFlightDetails(String strBookingID, String strNewSource, String strNewDate)
    {
        while(true)
        {
            if (!this._is_local())
            {
                org.omg.CORBA.portable.InputStream _input = null;
                try
                {
                    org.omg.CORBA.portable.OutputStream _output = this._request("fnTransferFlightDetails",true);
                    _output.write_string(strBookingID);
                    _output.write_string(strNewSource);
                    _output.write_string(strNewDate);
                    _input = this._invoke(_output);
                    String _arg_ret = _input.read_string();
                    return _arg_ret;
                }
                catch(org.omg.CORBA.portable.RemarshalException _exception)
                {
                    continue;
                }
                catch(org.omg.CORBA.portable.ApplicationException _exception)
                {
                    String _exception_id = _exception.getId();
                    throw new org.omg.CORBA.UNKNOWN("Unexpected User Exception: "+ _exception_id);
                }
                finally
                {
                    this._releaseReply(_input);
                }
            }
            else
            {
                org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke("fnTransferFlightDetails",_opsClass);
                if (_so == null)
                   continue;
                FlightReservation.FlightReservationInterfaceOperations _self = (FlightReservation.FlightReservationInterfaceOperations) _so.servant;
                try
                {
                    return _self.fnTransferFlightDetails( strBookingID,  strNewSource,  strNewDate);
                }
                finally
                {
                    _servant_postinvoke(_so);
                }
            }
        }
    }

    /**
     * Operation Createflights
     */
    public String Createflights(String Fromloc, String to_loc, String Date)
    {
        while(true)
        {
            if (!this._is_local())
            {
                org.omg.CORBA.portable.InputStream _input = null;
                try
                {
                    org.omg.CORBA.portable.OutputStream _output = this._request("Createflights",true);
                    _output.write_string(Fromloc);
                    _output.write_string(to_loc);
                    _output.write_string(Date);
                    _input = this._invoke(_output);
                    String _arg_ret = _input.read_string();
                    return _arg_ret;
                }
                catch(org.omg.CORBA.portable.RemarshalException _exception)
                {
                    continue;
                }
                catch(org.omg.CORBA.portable.ApplicationException _exception)
                {
                    String _exception_id = _exception.getId();
                    throw new org.omg.CORBA.UNKNOWN("Unexpected User Exception: "+ _exception_id);
                }
                finally
                {
                    this._releaseReply(_input);
                }
            }
            else
            {
                org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke("Createflights",_opsClass);
                if (_so == null)
                   continue;
                FlightReservation.FlightReservationInterfaceOperations _self = (FlightReservation.FlightReservationInterfaceOperations) _so.servant;
                try
                {
                    return _self.Createflights( Fromloc,  to_loc,  Date);
                }
                finally
                {
                    _servant_postinvoke(_so);
                }
            }
        }
    }

}
