package FlightReservation;

import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.Socket;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.rmi.RemoteException;
import java.text.DateFormat;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.logging.FileHandler;
import java.util.logging.Logger;

import org.omg.CORBA.ORB;

import java.io.Serializable;

public class FlightReservationImplementation extends
		FlightReservationInterfacePOA implements Runnable, java.io.Serializable {
	private ORB orb;

	HashMap<String, CustomerDetails> hmCustomerDetails = null;
	HashMap<String, FlightDetails> hmMontrealFlightDetails = null;
	HashMap<String, FlightDetails> hmNewdelhiFlightDetails = null;
	HashMap<String, FlightDetails> hmWashingtonFlightDetails = null;
	HashMap<String, FlightDetails> hmFlightDetails = null;
	FlightDetails objFlightDetails = null;
	CustomerDetails objCustomerDetails = null;
	Integer iBookingId;
	int iNoOfSeatsBookedInMontreal = 0;
	int iNoOfSeatsBookedInNewdelhi = 0;
	int iNoOfSeatsBookedInWashington = 0;
	boolean flag = true;

	public FlightReservationImplementation() throws ParseException {
		// super();

		hmCustomerDetails = new HashMap<String, CustomerDetails>();
		// objFlightDetails = new FlightDetails();
		objCustomerDetails = new CustomerDetails();
		iBookingId = 1;
		iNoOfSeatsBookedInMontreal = 0;
		iNoOfSeatsBookedInNewdelhi = 0;
		iNoOfSeatsBookedInWashington = 0;

		// hmMontrealFlightDetails = fnAddDefaultFlightsFromMontreal();
		// hmNewdelhiFlightDetails = fnAddDefaultFlightsFromNewdelhi();
		// hmWashingtonFlightDetails = fnAddDefaultFlightsFromWashington();
		hmFlightDetails = new HashMap<String, FlightDetails>();

		fncreateLogFile();
	}

	public synchronized String fnBookFlight(String strCustomerFirstName,
			String strCustomerLastName, String strCustomerAddress,
			String dCustomerPhoneNumber, String strFlightSource,
			String strFlightDestination, String strFlightDate,
			String strFlightClass) {
		// TODO Auto-generated method stub

		/*
		 * switch (strFlightSource.toLowerCase()) { case "mtl": hmFlightDetails
		 * = hmMontrealFlightDetails; break; case "ndl": hmFlightDetails =
		 * hmNewdelhiFlightDetails; break; case "WST": hmFlightDetails =
		 * hmWashingtonFlightDetails; break; }
		 */

		try {
			objCustomerDetails.strCustomerFirstName = strCustomerFirstName;
			objCustomerDetails.strCustomerLastName = strCustomerLastName;
			objCustomerDetails.strCustomerAddress = strCustomerAddress;
			objCustomerDetails.dCustomerPhoneNumber = dCustomerPhoneNumber;
			objCustomerDetails.strClassBooked = strFlightClass.toLowerCase();
			// objCustomerDetails.iBookingID = iBookingId;

			// DateFormat df = new SimpleDateFormat("dd/MM/yyyy");
			// System.out.println(df.format(dtFlightDate));

			String strSearchId = strFlightSource.toUpperCase() + "-"
					+ strFlightDestination.toUpperCase() + "-" + strFlightDate;

			objFlightDetails = hmFlightDetails.get(strSearchId);

			if (objFlightDetails != null && objFlightDetails.iTotalSeats > 0) {
				if (strFlightClass.equalsIgnoreCase("E")
						&& objFlightDetails.iEconomySeats == 0) {
					System.out
							.println("No more seats available in economy class. Select Premium class");
					// return
					// "No more seats available in economy class. Select Premium class";
					return "false";
				} else if (strFlightClass.equalsIgnoreCase("B")
						&& objFlightDetails.iPremiumSeats == 0) {
					System.out
							.println("No more seats available in premium class. Select economy class");
					// return
					// "No more seats available in premium class. Select economy class";
					return "false";
				}

				// check for customer details in hash map. else add it.
				/*
				 * String strHashMapKey = strCustomerLastName.substring(0, 1)
				 * .toUpperCase(); List<CustomerDetails> lstCustomers =
				 * hmCustomerDetails .get(strHashMapKey); if (lstCustomers ==
				 * null) { lstCustomers = new ArrayList<CustomerDetails>();
				 * hmCustomerDetails.put(strHashMapKey, lstCustomers); }
				 */

				objCustomerDetails.strsBookingID = strSearchId + "."
						+ iBookingId.toString();
				// lstCustomers.add(objCustomerDetails);

				synchronized (hmCustomerDetails) {
					hmCustomerDetails.put(objCustomerDetails.strsBookingID,
							objCustomerDetails);
				}

				// increment the counter value
				iBookingId++;

				switch (strFlightSource.toLowerCase()) {
				case "mtl":
					iNoOfSeatsBookedInMontreal++;
					break;
				case "ndl":
					iNoOfSeatsBookedInNewdelhi++;
					break;
				case "WST":
					iNoOfSeatsBookedInWashington++;
					break;
				}

				// Reduce the Flight seat after booking
				objFlightDetails.iTotalSeats--;
				if (strFlightClass.equalsIgnoreCase("E"))
					objFlightDetails.iEconomySeats--;
				else
					objFlightDetails.iPremiumSeats--;

				// hmFlightDetails.put(iBookingId, objFlightDetails);

				// System.out.println("Ticket booked\n");
				// fnTracelog("flight booked : " +
				// objCustomerDetails.toString());

				int i = 1;
				Set set = hmFlightDetails.entrySet();
				java.util.Iterator iterator = set.iterator();
				while (iterator.hasNext()) {
					Map.Entry mentry = (Map.Entry) iterator.next();
					System.out.println(i + ". " + mentry.getValue());
					i++;
				}

				// return "Ticket booked. Ticket ID : "
				// + objCustomerDetails.strsBookingID;
				return "true";

			} else {
				// System.out.println("Flight not available that destination");
				// return "Flight not available that destination";
				return "false";
			}

		} catch (Exception e) { // TODO Auto-generated catch block
			System.out.println(e.toString());
			System.out.println(e.getStackTrace());
			// return "Error while booking flight. try again later";
			return "false";
		}
	}

	public String fnEditFlightRecord(String strManagerId, String strFlightId,
			String strFieldName, String strValue, String strOption) {
		// TODO Auto-generated method stub
		System.out.println(strManagerId);

		/*
		 * switch (strManagerId.substring(0, 3).toLowerCase()) { case "mtl":
		 * hmFlightDetails = hmMontrealFlightDetails; break; case "ndl":
		 * hmFlightDetails = hmNewdelhiFlightDetails; break; case "wst":
		 * hmFlightDetails = hmWashingtonFlightDetails; break; }
		 */

		System.out.println(strManagerId);
		System.out.println(strFlightId);
		System.out.println(strFieldName);
		System.out.println(strValue);
		System.out.println(strOption);

		if (strOption.equalsIgnoreCase("edit")) {

			/*
			 * 
			 * if (Objects.equals(opt, "edit")) { synchronized (LOCK) { try {
			 * 
			 * 
			 * FlightDetails flit = new FlightDetails(); flit =
			 * Flightdata.get(key); if (Objects.equals(fieldName, "date")) {
			 * /*DateFormat formatter = new SimpleDateFormat( "dd/MM/yyyy");
			 * Date startDate = (Date) formatter.parse(newValue); flit.date =
			 * newValue; } else if (Objects.equals(fieldName, "From_loc")) {
			 * flit.From_loc = newValue; } else if (Objects.equals(fieldName,
			 * "To_loc")) { flit.To_loc = newValue; } else if
			 * (Objects.equals(fieldName, "totals")) { flit.totals =
			 * Integer.parseInt(newValue); } else if (Objects.equals(fieldName,
			 * "EclassTkts")) { flit.EclassTkts = Integer.parseInt(newValue); }
			 * else if (Objects.equals(fieldName, "BclassTkts")) {
			 * flit.BclassTkts = Integer.parseInt(newValue); ; } if
			 * (Objects.equals(flit.From_loc, flit.To_loc)) {
			 * System.out.println("From loc and To loc cant be same"); return
			 * false; } flit.totals = flit.EclassTkts + flit.BclassTkts;
			 * Flightdata.remove(key); Flightdata.put(key, flit);
			 * System.out.println("Successfully edited"); return true; } catch
			 * (Exception e) { System.out.println("Error in editFlightRecord " +
			 * e.getMessage()); return false; } } }
			 */

			FlightDetails objFlight = hmFlightDetails.get(strFlightId);
			hmFlightDetails.remove(strFlightId);

			switch (strFieldName.toLowerCase()) {
			case "source":
				objFlight.strFlightSource = strValue;
				break;
			case "destination":
				objFlight.strFlightDestination = strValue;
				break;
			case "flightdate":
				// DateFormat df = new SimpleDateFormat("dd/MM/yyyy");
				objFlight.dtFlightDate = strValue;
				break;
			case "economyseats":
				objFlight.iEconomySeats = Integer.parseInt(strValue);
				if (objFlight.strFlightSource.toLowerCase().equalsIgnoreCase(
						"mtl"))
					iNoOfSeatsBookedInMontreal = Integer.parseInt(strValue);
				if (objFlight.strFlightSource.toLowerCase().equalsIgnoreCase(
						"ndl"))
					iNoOfSeatsBookedInNewdelhi = Integer.parseInt(strValue);
				if (objFlight.strFlightSource.toLowerCase().equalsIgnoreCase(
						"WST"))
					iNoOfSeatsBookedInWashington = Integer.parseInt(strValue);
				// flag = false;
				break;
			case "premiumseats":
				objFlight.iPremiumSeats = Integer.parseInt(strValue);
				if (objFlight.strFlightSource.toLowerCase().equalsIgnoreCase(
						"mtl"))
					iNoOfSeatsBookedInMontreal = Integer.parseInt(strValue);
				if (objFlight.strFlightSource.toLowerCase().equalsIgnoreCase(
						"ndl"))
					iNoOfSeatsBookedInNewdelhi = Integer.parseInt(strValue);
				if (objFlight.strFlightSource.toLowerCase().equalsIgnoreCase(
						"WST"))
					iNoOfSeatsBookedInWashington = Integer.parseInt(strValue);
				break;
			}
			// DateFormat df = new SimpleDateFormat("dd/MM/yyyy");
			objFlight.iTotalSeats = objFlight.iEconomySeats
					+ objFlight.iPremiumSeats;
			objFlight.strFlightId = objFlight.strFlightSource + "-"
					+ objFlight.strFlightDestination + "-"
					+ objFlight.dtFlightDate;
			hmFlightDetails.put(objFlight.strFlightId, objFlight);

			System.out.println("Flight Edited");
			return "true";
		} else if (strOption.equalsIgnoreCase("create")) {
			FlightDetails objFlight = new FlightDetails();
			objFlight.strFlightSource = strFlightId;
			objFlight.strFlightDestination = strFieldName;
			objFlight.dtFlightDate = strValue;
			objFlight.strFlightId = strFlightId + "-" + strFieldName + "-"
					+ strValue;
			hmFlightDetails.put(objFlight.strFlightId, objFlight);
			// return "Created successfully";
			return "true";
		} else if (strOption.equalsIgnoreCase("delete")) {
			try {
				{
					hmFlightDetails.remove(strFlightId);
					System.out.println("Successfully Deleted");
					// return "Successfully Deleted";
					return "true";
				}
			} catch (Exception e) {
				System.out.println("Error in editFlightRecord "
						+ e.getMessage());
				// return "Error in editFlightRecord";
				return "false";
			}
		}
		int i = 1;
		Set set = hmFlightDetails.entrySet();
		java.util.Iterator iterator = set.iterator();
		while (iterator.hasNext()) {
			Map.Entry mentry = (Map.Entry) iterator.next();
			System.out.println(i + ". " + mentry.getValue());
			i++;
		}
		return "true";

		// return "Flight Edited";

	}

	public String fnTransferFlightDetails(String strBookingID,
			String strNewSource, String strNewDate) {
		// TODO Auto-generated method stub

		// System.out.println("method enter");

		CustomerDetails objCustomer = this.hmCustomerDetails.get(strBookingID);

		String[] parts = strBookingID.split("-");
		String strOldSource = parts[0];
		String strOldDest = parts[1];
		String[] date = parts[2].split("\\.");

		if (objCustomer == null) {
			// return "No records found for the booking ID.";
			return "false";
		}

		else {
			// System.out.println("else enter");

			byte[] bReceiveData = new byte[100];
			byte[] bSendData = null;

			DatagramPacket dpSendPacket = null;
			DatagramPacket dpReceivePacket = new DatagramPacket(bReceiveData,
					bReceiveData.length);

			try {
				InetAddress ipHostAddress = InetAddress.getByName("localhost");
				DatagramSocket dgSocket = new DatagramSocket();
				String strReplyFromServer = "";

				String strRequest = strNewSource + "," + strOldDest + ","
						+ strNewDate + "," + objCustomer.strCustomerFirstName
						+ "," + objCustomer.strCustomerLastName + ","
						+ objCustomer.strCustomerAddress;

				bSendData = strRequest.getBytes();

				if (strNewSource.equalsIgnoreCase("MTL")) {
					dpSendPacket = new DatagramPacket(bSendData,
							bSendData.length, ipHostAddress, 7000);
					dgSocket.send(dpSendPacket);
					dgSocket.receive(dpReceivePacket);
				} else if (strNewSource.equalsIgnoreCase("NDL")) {
					dpSendPacket = new DatagramPacket(bSendData,
							bSendData.length, ipHostAddress, 8000);
					dgSocket.send(dpSendPacket);
					dgSocket.receive(dpReceivePacket);
				} else if (strNewSource.equalsIgnoreCase("WST")) {
					dpSendPacket = new DatagramPacket(bSendData,
							bSendData.length, ipHostAddress, 9000);
					dgSocket.send(dpSendPacket);
					dgSocket.receive(dpReceivePacket);
				}
				strReplyFromServer = new String(
						trim(dpReceivePacket.getData()), "UTF-8");

				System.out.println(strReplyFromServer);

				if (strReplyFromServer.contains("Ticket booked")) {
					fnwriteLog("TransferFlight", "transfer", "success",
							strReplyFromServer);
					this.hmCustomerDetails.remove(strBookingID);
					fnTracelog("Record removed from old server");
				}

				fnwriteLog("TransferFlight", "transfer", "failure",
						strReplyFromServer);

				/*
				 * switch (strOldSource.toLowerCase()) { case "mtl":
				 * hmFlightDetails = hmMontrealFlightDetails; break; case "ndl":
				 * hmFlightDetails = hmNewdelhiFlightDetails; break; case "wst":
				 * hmFlightDetails = hmWashingtonFlightDetails; break; }
				 */

				// System.out.println(parts[2]);
				// System.out.println(date[0]);

				FlightDetails objOldFlightRecord = hmFlightDetails
						.get(strOldSource + "-" + strOldDest + "-" + date[0]);

				if (objOldFlightRecord != null) {
					if (objCustomer.strClassBooked.equalsIgnoreCase("E"))
						objOldFlightRecord.iEconomySeats++;
					else
						objOldFlightRecord.iPremiumSeats++;
					objOldFlightRecord.iTotalSeats++;
				}

				int i = 1;
				Set set = this.hmFlightDetails.entrySet();
				java.util.Iterator iterator = set.iterator();
				while (iterator.hasNext()) {
					Map.Entry mentry = (Map.Entry) iterator.next();
					System.out.println(i + ". " + mentry.getValue());
					i++;
				}

				// return strReplyFromServer;
				return "true";
			}

			catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				return "";
			}
		}
	}

	public void fnOpenUDPServer(int iPortNumber, String strLocation)
			throws IOException {
		DatagramSocket dUDPSocket = new DatagramSocket(iPortNumber);

		System.out.println(strLocation + " UDP server is running");
		while (true) {
			try {
				byte[] receiveData = new byte[510];
				byte[] sendData = new byte[5024];
				DatagramPacket receivePacket = new DatagramPacket(receiveData,
						receiveData.length);
				dUDPSocket.receive(receivePacket);
				String strRequest = new String(trim(receivePacket.getData()));
				// System.out.println(strRequest);

				InetAddress IPAddress = receivePacket.getAddress();
				int iPort = receivePacket.getPort();

				if (strRequest.equalsIgnoreCase("heart")) {
					sendData = (strLocation + " up").getBytes();

					DatagramPacket sendPacket = new DatagramPacket(sendData,
							sendData.length, IPAddress, iPort);
					dUDPSocket.send(sendPacket);

				} else if (strRequest.equalsIgnoreCase("restorecustomer")) {

					int port = receivePacket.getPort();

					ByteArrayOutputStream baos = new ByteArrayOutputStream();
					ObjectOutputStream oos = new ObjectOutputStream(baos);
					oos.writeObject(hmCustomerDetails);
					oos.flush();
					byte[] Buf = baos.toByteArray();
					DatagramPacket sendPacket = new DatagramPacket(Buf,
							Buf.length, IPAddress, port);
					dUDPSocket.send(sendPacket);
					System.out.println("Sent");

					sendData = baos.toByteArray();

					System.out.println(new String(sendData));

					Thread.sleep(2000);

				} else if (strRequest.equalsIgnoreCase("restoreflight")) {
					int port = receivePacket.getPort();

					ByteArrayOutputStream baos = new ByteArrayOutputStream();
					ObjectOutputStream oos = new ObjectOutputStream(baos);
					oos.writeObject(hmFlightDetails);
					oos.flush();
					byte[] Buf = baos.toByteArray();
					DatagramPacket sendPacket = new DatagramPacket(Buf,
							Buf.length, IPAddress, port);
					dUDPSocket.send(sendPacket);
					System.out.println("Sent");

					sendData = baos.toByteArray();

					System.out.println(new String(sendData));

					Thread.sleep(2000);

				}

				else if (strRequest.equalsIgnoreCase("count")) {
					// String strResult = fnGetTicketCount(strLocation);
					int i = 0;
					Set set = this.hmCustomerDetails.entrySet();
					java.util.Iterator iterator = set.iterator();
					while (iterator.hasNext()) {
						Map.Entry mentry = (Map.Entry) iterator.next();
						i++;
					}

					String strResult = Integer.toString(i);
					sendData = strResult.getBytes();
					System.out.println(strResult);

					DatagramPacket sendPacket = new DatagramPacket(sendData,
							sendData.length, IPAddress, iPort);
					dUDPSocket.send(sendPacket);
				} else {
					// System.out.println(strRequest);
					String[] parts = strRequest.split(",");

					String strResponse = fnBookUpdatedFlight(parts[0],
							parts[1], parts[2], parts[3], parts[4], parts[5]);
					sendData = strResponse.getBytes();
					// System.out.println("server response");
					System.out.println(strResponse);

					DatagramPacket sendPacket = new DatagramPacket(sendData,
							sendData.length, IPAddress, iPort);
					dUDPSocket.send(sendPacket);
				}

			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	private synchronized String fnBookUpdatedFlight(String strSource,
			String strDest, String strDate, String strFirstName,
			String strLastName, String strAddress) {
		// TODO Auto-generated method stub
		// System.out.println("booking new ticket...");

		String strSearchId = strSource.toUpperCase() + "-"
				+ strDest.toUpperCase() + "-" + strDate;

		// System.out.println(strSearchId);

		/*
		 * switch (strSource.toLowerCase()) { case "mtl": hmFlightDetails =
		 * hmMontrealFlightDetails; break; case "ndl": hmFlightDetails =
		 * hmNewdelhiFlightDetails; break; case "wst": hmFlightDetails =
		 * hmWashingtonFlightDetails; break; }
		 */

		objFlightDetails = hmFlightDetails.get(strSearchId);

		if (objFlightDetails != null) {
			if (objFlightDetails.iTotalSeats > 0) {

				if (objFlightDetails.iEconomySeats > 0) {
					// System.out
					// .println("No more seats available in economy class. Select Premium class");
					// return
					// "No more seats available in economy class. Select Premium class";
					objFlightDetails.iEconomySeats--;
					objCustomerDetails.strClassBooked = "E";
				} else if (objFlightDetails.iPremiumSeats > 0) {
					// System.out
					// .println("No more seats available in premium class. Select economy class");
					// return
					// "No more seats available in premium class. Select economy class";
					objFlightDetails.iPremiumSeats--;
					objCustomerDetails.strClassBooked = "B";
				}
				objFlightDetails.iTotalSeats--;

				objCustomerDetails.strsBookingID = strSearchId + "."
						+ this.iBookingId.toString();
				// lstCustomers.add(objCustomerDetails);

				try {
					fnTracelog("ticket booked. Booking ID: "
							+ objCustomerDetails.strsBookingID);
					fnwriteLog("BookFlight", "PUT", "success",
							objCustomerDetails.strsBookingID);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				synchronized (hmCustomerDetails) {
					this.hmCustomerDetails.put(
							objCustomerDetails.strsBookingID,
							objCustomerDetails);
				}
				// increment the counter value
				this.iBookingId++;

				int i = 1;
				Set set = hmFlightDetails.entrySet();
				java.util.Iterator iterator = set.iterator();
				while (iterator.hasNext()) {
					Map.Entry mentry = (Map.Entry) iterator.next();
					System.out.println(i + ". " + mentry.getValue());
					i++;
				}

				try {
					fnTracelog("Ticket booked. Ticket ID : "
							+ objCustomerDetails.strsBookingID);
					fnwriteLog("BookFlight", "PUT", "success",
							objCustomerDetails.strsBookingID);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				// return "Ticket booked. Ticket ID : "
				// + objCustomerDetails.strsBookingID;
				return "true";

			} else {
				// return "no tickets available in that flight.";
				fnwriteLog("BookFlight", "PUT", "failure",
						"no tickets available in that flight");
				return "false";

			}
		} else {
			// return "no flight available for the search criteria.";
			fnwriteLog("BookFlight", "PUT", "failure",
					"no flights available for the search criteria");
			return "false";
		}
	}

	public String fnGetBookedFlightCount(String strLocation) {
		// TODO Auto-generated method stub
		byte[] bReceiveData = new byte[10];
		byte[] bReceiveData2 = new byte[10];

		byte[] bSendData = new byte[10];
		byte[] bSendData2 = new byte[10];

		String strTotalCount = "false";
		// destination machine IP. Here we connect the same computer, so
		// "localhost"
		InetAddress ipHostAddress = null;
		try {
			ipHostAddress = InetAddress.getByName("localhost");
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		int j = 0;
		if (flag) {
			Set set1 = this.hmCustomerDetails.entrySet();
			java.util.Iterator iterator1 = set1.iterator();
			while (iterator1.hasNext()) {
				Map.Entry mentry = (Map.Entry) iterator1.next();
				// System.out.println(j + ". " + mentry.getValue());
				j++;
			}
		}

		DatagramPacket dpSendPacket = null;
		DatagramPacket dpSendPacket2 = null;
		// DatagramPacket dpReceivePacket = null;

		String strReplyFromServerOne = "";
		String strReplyFromServerTwo = "";

		bSendData = "count".getBytes();
		bSendData2 = "count".getBytes();

		DatagramPacket dpReceivePacket = new DatagramPacket(bReceiveData,
				bReceiveData.length);
		DatagramPacket dpReceivePacket2 = new DatagramPacket(bReceiveData2,
				bReceiveData2.length);

		try {
			DatagramSocket dgSocket = new DatagramSocket();
			DatagramSocket dgSocket2 = new DatagramSocket();

			if (strLocation.equalsIgnoreCase("MTL")) {

				dpSendPacket = new DatagramPacket(bSendData, bSendData.length,
						ipHostAddress, 8000);
				dgSocket.send(dpSendPacket);
				dgSocket.receive(dpReceivePacket);
				strReplyFromServerOne = new String(
						trim(dpReceivePacket.getData()), "UTF-8");
				// System.out.println("Its here");

				dpSendPacket2 = new DatagramPacket(bSendData2,
						bSendData2.length, ipHostAddress, 9000);
				dgSocket2.send(dpSendPacket2);
				dgSocket2.receive(dpReceivePacket2);
				strReplyFromServerTwo = new String(
						trim(dpReceivePacket2.getData()), "UTF-8");
				strTotalCount = "MTL : " + Integer.toString(j) + "," + "NDL : "
						+ strReplyFromServerOne + "," + "WSH : "
						+ strReplyFromServerTwo;
				// System.out.println("Its here2");
			} else if (strLocation.equalsIgnoreCase("ndl")) {
				dpSendPacket = new DatagramPacket(bSendData, bSendData.length,
						ipHostAddress, 7000);
				dgSocket.send(dpSendPacket);
				dgSocket.receive(dpReceivePacket);
				strReplyFromServerOne = new String(
						trim(dpReceivePacket.getData()), "UTF-8");
				// System.out.println("Its here");
				dpSendPacket2 = new DatagramPacket(bSendData2,
						bSendData2.length, ipHostAddress, 9000);
				dgSocket2.send(dpSendPacket2);
				dgSocket2.receive(dpReceivePacket2);
				strReplyFromServerTwo = new String(
						trim(dpReceivePacket2.getData()), "UTF-8");
				strTotalCount = "MTL : " + strReplyFromServerOne + ","
						+ "NDL : " + Integer.toString(j) + "," + "WST : "
						+ strReplyFromServerTwo;

			} else if (strLocation.equalsIgnoreCase("wst")) {
				dpSendPacket = new DatagramPacket(bSendData, bSendData.length,
						ipHostAddress, 7000);
				dgSocket.send(dpSendPacket);
				dgSocket.receive(dpReceivePacket);
				strReplyFromServerOne = new String(
						trim(dpReceivePacket.getData()), "UTF-8");
				// System.out.println("Its here");
				dpSendPacket2 = new DatagramPacket(bSendData2,
						bSendData2.length, ipHostAddress, 8000);
				dgSocket2.send(dpSendPacket2);
				dgSocket2.receive(dpReceivePacket2);
				strReplyFromServerTwo = new String(
						trim(dpReceivePacket2.getData()), "UTF-8");
				strTotalCount = "MTL : " + strReplyFromServerOne + ","
						+ "NDL : " + strReplyFromServerTwo + "," + "WST : "
						+ Integer.toString(j);

			}
		} catch (Exception e) {
			System.out.println("Error in UDP client.");
		}
		return strTotalCount;

	}

	public String fnGetTicketCount(String strLocation) {

		String strValue = "";
		switch (strLocation.toLowerCase()) {
		case "mtl":
			strValue = Integer.toString(iNoOfSeatsBookedInMontreal);
			break;
		case "ndl":
			strValue = Integer.toString(iNoOfSeatsBookedInNewdelhi);
			break;
		case "WST":
			strValue = Integer.toString(iNoOfSeatsBookedInWashington);
			break;
		}
		return strValue;
	}

	public void setORB(ORB orb_val) {
		orb = orb_val;
	}

	public void shutdown() {
		orb.shutdown(false);
	}

	public void fnTracelog(String strLog) throws IOException {
		try {
			Logger logger = Logger.getLogger("MyLog");
			// FileHandler fh;
			FileHandler fileHandler = new FileHandler("app.log", true);
			logger.addHandler(fileHandler);

			logger.info(strLog);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("error in trace");
		}

	}

	static byte[] trim(byte[] bytes) {
		int i = bytes.length - 1;
		while (i >= 0 && bytes[i] == 0) {
			--i;
		}

		return Arrays.copyOf(bytes, i + 1);
	}

	public HashMap<String, FlightDetails> fnAddDefaultFlightsFromMontreal()
			throws ParseException {

		HashMap<String, FlightDetails> hmFlightRecords = new HashMap<String, FlightDetails>();

		FlightDetails objFlight = new FlightDetails();

		objFlight.strFlightSource = "MTL";
		objFlight.strFlightDestination = "NDL";
		objFlight.dtFlightDate = "10/11/2016";
		objFlight.strFlightId = "MTL-NDL-10/11/2016";
		hmFlightRecords.put("MTL-NDL-10/11/2016", objFlight);

		objFlight = new FlightDetails();
		objFlight.strFlightSource = "MTL";
		objFlight.strFlightDestination = "NDL";
		objFlight.dtFlightDate = "15/11/2016";
		objFlight.strFlightId = "MTL-NDL-15/11/2016";
		hmFlightRecords.put("MTL-NDL-15/11/2016", objFlight);

		objFlight = new FlightDetails();
		objFlight.strFlightSource = "MTL";
		objFlight.strFlightDestination = "WST";
		objFlight.dtFlightDate = "13/11/2016";
		objFlight.strFlightId = "MTL-WST-13/11/2016";
		hmFlightRecords.put("MTL-WST-13/11/2016", objFlight);

		return hmFlightRecords;
	}

	public HashMap<String, FlightDetails> fnAddDefaultFlightsFromNewdelhi()
			throws ParseException {
		HashMap<String, FlightDetails> hmFlightRecords = new HashMap<String, FlightDetails>();

		FlightDetails objFlight = new FlightDetails();

		objFlight.strFlightSource = "NDL";
		objFlight.strFlightDestination = "MTL";
		objFlight.dtFlightDate = "10/11/2016";
		objFlight.strFlightId = "NDL-MTL-10/11/2016";
		hmFlightRecords.put("NDL-MTL-10/11/2016", objFlight);

		objFlight = new FlightDetails();
		objFlight.strFlightSource = "NDL";
		objFlight.strFlightDestination = "MTL";
		objFlight.dtFlightDate = "15/11/2016";
		objFlight.strFlightId = "NDL-MTL-15/11/2016";
		hmFlightRecords.put("NDL-MTL-15/11/2016", objFlight);

		objFlight = new FlightDetails();
		objFlight.strFlightSource = "NDL";
		objFlight.strFlightDestination = "WST";
		objFlight.dtFlightDate = "13/11/2016";
		objFlight.strFlightId = "NDL-WST-13/11/2016";
		hmFlightRecords.put("NDL-WST-13/11/2016", objFlight);

		return hmFlightRecords;
	}

	public HashMap<String, FlightDetails> fnAddDefaultFlightsFromWashington()
			throws ParseException {
		HashMap<String, FlightDetails> hmFlightRecords = new HashMap<String, FlightDetails>();

		FlightDetails objFlight = new FlightDetails();

		objFlight.strFlightSource = "WST";
		objFlight.strFlightDestination = "NDL";
		objFlight.dtFlightDate = "10/11/2016";
		objFlight.strFlightId = "WST-NDL-10/11/2016";
		hmFlightRecords.put("WST-NDL-10/11/2016", objFlight);

		objFlight = new FlightDetails();
		objFlight.strFlightSource = "WST";
		objFlight.strFlightDestination = "NDL";
		objFlight.dtFlightDate = "15/11/2016";
		objFlight.strFlightId = "WST-NDL-15/11/2016";
		hmFlightRecords.put("WST-NDL-15/11/2016", objFlight);

		objFlight = new FlightDetails();
		objFlight.strFlightSource = "WST";
		objFlight.strFlightDestination = "MTL";
		objFlight.dtFlightDate = "13/11/2016";
		objFlight.strFlightId = "WST-MTL-13/11/2016";
		hmFlightRecords.put("WST-MTL-13/11/2016", objFlight);

		return hmFlightRecords;
	}

	public String Createflights(String Fromloc, String to_loc, String Date) {
		FlightDetails flit = new FlightDetails();
		// Date d = new Date();
		System.out.println("Here");
		String Key = Fromloc + "-" + to_loc + "-" + Date;
		System.out.println(Key);
		flit.dtFlightDate = Date;
		flit.strFlightSource = Fromloc;
		flit.strFlightDestination = to_loc;

		hmFlightDetails.put(Key, flit);

		return "true";

	}

	@Override
	public void run() {
		// TODO Auto-generated method stub

	}

	public void reinstate(HashMap<String, CustomerDetails> c,
			HashMap<String, FlightDetails> f) {
		hmCustomerDetails = c;
		hmFlightDetails = f;
	}

	private void fncreateLogFile() {
		String filePath = "ServerLog.txt";
		File logFile = new File(filePath);
		try {
			PrintWriter pw = new PrintWriter(new FileWriter(filePath), true);
			// create a new file
			if (!logFile.exists()) {
				logFile.createNewFile();
			} else {
				// clear the old file contents
				pw.write("");
			}
			pw.printf("%-15s %-15s %-15s %-20s %-40s", "Operation", "Type",
					"Name", "Date", "Status");
			pw.println();
			pw.write("-------------------------------------------------------------------------------------------------");
			pw.println();
			pw.flush();
			pw.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	// ================================ Writes into Log File with the requested
	// operation details =============== //
	public void fnwriteLog(String operation, String type, String recordID,
			String msgStatus) {
		String filePath = "ServerLog.txt";
		PrintWriter pw;
		DateFormat shortDf = DateFormat.getDateTimeInstance(DateFormat.SHORT,
				DateFormat.SHORT);
		try {
			pw = new PrintWriter(new FileWriter(filePath, true));
			pw.printf("%-15s %-15s %-15s %-20s %-60s", operation, type,
					recordID, shortDf.format(new Date()), msgStatus);
			pw.println();
			pw.flush();
			pw.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
