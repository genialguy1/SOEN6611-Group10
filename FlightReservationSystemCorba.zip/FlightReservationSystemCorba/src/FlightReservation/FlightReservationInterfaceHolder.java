package FlightReservation;

/**
 * Holder class for : FlightReservationInterface
 * 
 * @author OpenORB Compiler
 */
final public class FlightReservationInterfaceHolder
        implements org.omg.CORBA.portable.Streamable
{
    /**
     * Internal FlightReservationInterface value
     */
    public FlightReservation.FlightReservationInterface value;

    /**
     * Default constructor
     */
    public FlightReservationInterfaceHolder()
    { }

    /**
     * Constructor with value initialisation
     * @param initial the initial value
     */
    public FlightReservationInterfaceHolder(FlightReservation.FlightReservationInterface initial)
    {
        value = initial;
    }

    /**
     * Read FlightReservationInterface from a marshalled stream
     * @param istream the input stream
     */
    public void _read(org.omg.CORBA.portable.InputStream istream)
    {
        value = FlightReservationInterfaceHelper.read(istream);
    }

    /**
     * Write FlightReservationInterface into a marshalled stream
     * @param ostream the output stream
     */
    public void _write(org.omg.CORBA.portable.OutputStream ostream)
    {
        FlightReservationInterfaceHelper.write(ostream,value);
    }

    /**
     * Return the FlightReservationInterface TypeCode
     * @return a TypeCode
     */
    public org.omg.CORBA.TypeCode _type()
    {
        return FlightReservationInterfaceHelper.type();
    }

}
