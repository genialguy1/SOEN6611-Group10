package FlightReservation;

import java.util.Date;
import java.io.Serializable;

public class FlightDetails {
	public String strFlightSource;
	public String strFlightDestination;
	public String strFlightClass;
	public String dtFlightDate;
	public int iTotalSeats = 15;
	public int iPremiumSeats = 5;
	public int iEconomySeats = 10;

	String strFlightId;

	public FlightDetails(String Source) {
		this.strFlightSource = Source;
	}

	public FlightDetails() {
	}

	public String toString() {
		return String
				.format("Flight Origin: %s, Flight Dest: %s, Flight Date: %s, Economy Seats: %d, Premium Seats: %d",
						strFlightSource, strFlightDestination, dtFlightDate,
						iEconomySeats, iPremiumSeats);
	}

}
