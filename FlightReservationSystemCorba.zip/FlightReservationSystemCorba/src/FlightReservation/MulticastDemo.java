package FlightReservation;

import java.io.File;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.util.Arrays;
import java.util.Map;
import java.util.Set;

import javax.lang.model.element.Element;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.xpath.XPath;

import org.w3c.dom.Node;
import org.xml.sax.InputSource;

import com.sun.org.apache.xml.internal.security.utils.XPathFactory;
import com.sun.xml.internal.txw2.Document;

public class MulticastDemo {

	public static void main(String[] args) throws SocketException {

		Runnable t1 = new Runnable() {
			public void run() {

				try {
					fnOpenUDPReplicaManagerOne();
				} catch (SocketException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		};
		Runnable t2 = new Runnable() {
			public void run() {

				try {
					fnOpenUDPReplicaManagertwo();
				} catch (SocketException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		};
		Runnable t3 = new Runnable() {
			public void run() {

				try {
					fnOpenUDPReplicaManagerthree();
				} catch (SocketException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		};
		Runnable t4 = new Runnable() {
			public void run() {

				try {
					fnOpenUDPReplicaManagerfour();
				} catch (SocketException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		};

		/*
		 * new Thread(t1).start(); new Thread(t2).start(); new
		 * Thread(t3).start(); new Thread(t4).start();
		 */

		// TODO Auto-generated method stub
		byte[] bReceiveData = new byte[100];
		byte[] bReceiveData2 = new byte[100];
		byte[] bReceiveData3 = new byte[100];
		byte[] bReceiveData4 = new byte[100];

		byte[] bSendData = new byte[100];
		byte[] bSendData2 = new byte[100];
		byte[] bSendData3 = new byte[100];
		byte[] bSendData4 = new byte[100];

		// String strTotalCount = "";
		// destination machine IP. Here we connect the same computer, so
		// "localhost"
		InetAddress ipHostAddress = null;
		try {
			ipHostAddress = InetAddress.getByName("localhost");
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		DatagramSocket dgSocket = new DatagramSocket();
		DatagramSocket dgSocket2 = new DatagramSocket();
		DatagramSocket dgSocket3 = new DatagramSocket();
		DatagramSocket dgSocket4 = new DatagramSocket();
		DatagramPacket dpSendPacket = null;
		DatagramPacket dpSendPacket2 = null;
		DatagramPacket dpSendPacket3 = null;
		DatagramPacket dpSendPacket4 = null;
		// DatagramPacket dpReceivePacket = null;

		String strReplyFromServerOne = "";
		String strReplyFromServerTwo = "";
		String strReplyFromServerThree = "";
		String strReplyFromServerFour = "";

		try {
			DocumentBuilderFactory factory = DocumentBuilderFactory
					.newInstance();
			DocumentBuilder builder = factory.newDocumentBuilder();
			org.w3c.dom.Document document = builder
					.parse(new File(
							"C:/Users/Goutham/workspace1/FlightReservationSystemCorba/src/FlightReservation/sequencer.xml"));
			
			org.w3c.dom.Element rootElement = document.getDocumentElement();
			System.out.println(rootElement.getNodeValue());
		} catch (Exception e) {
			e.printStackTrace();
		}

		bSendData = "1]bookflight[goutham,raj,chennai,12345,NDL,MTL,10/11/2016,e"
				.getBytes();
		bSendData2 = "2]bookflight[goutham,raj,chennai,12345,MTL,NDL,10/11/2016,e"
				.getBytes();
		bSendData3 = bSendData2;
		bSendData4 = bSendData2;

		DatagramPacket dpReceivePacket = new DatagramPacket(bReceiveData,
				bReceiveData.length);
		DatagramPacket dpReceivePacket2 = new DatagramPacket(bReceiveData2,
				bReceiveData2.length);
		DatagramPacket dpReceivePacket3 = new DatagramPacket(bReceiveData2,
				bReceiveData2.length);
		DatagramPacket dpReceivePacket4 = new DatagramPacket(bReceiveData2,
				bReceiveData2.length);

		try {
			System.out.println("sending");
			dpSendPacket = new DatagramPacket(bSendData, bSendData.length,
					ipHostAddress, 9011);
			dgSocket.send(dpSendPacket);

			// dgSocket.receive(dpReceivePacket);
			// strReplyFromServerOne = new
			// String(trim(dpReceivePacket.getData()),
			// "UTF-8");
			// System.out.println(strReplyFromServerOne);

			dpSendPacket2 = new DatagramPacket(bSendData2, bSendData2.length,
					ipHostAddress, 9022);
			dgSocket2.send(dpSendPacket2);

			dgSocket2.receive(dpReceivePacket2);
			strReplyFromServerTwo = new String(
					trim(dpReceivePacket2.getData()), "UTF-8");
			// System.out.println(strReplyFromServerTwo);

			/*
			 * dpSendPacket3 = new DatagramPacket(bSendData3, bSendData3.length,
			 * ipHostAddress, 8003); dgSocket3.send(dpSendPacket3);
			 * 
			 * dgSocket3.receive(dpReceivePacket3); strReplyFromServerThree =
			 * new String( trim(dpReceivePacket3.getData()), "UTF-8");
			 * 
			 * dpSendPacket4 = new DatagramPacket(bSendData4, bSendData4.length,
			 * ipHostAddress, 8004); dgSocket4.send(dpSendPacket4);
			 * 
			 * dgSocket4.receive(dpReceivePacket4); strReplyFromServerFour = new
			 * String( trim(dpReceivePacket4.getData()), "UTF-8");
			 */

		} catch (Exception e) {
			System.out.println("Error in UDP client.");
		}
		System.out.println(strReplyFromServerOne);
		System.out.println(strReplyFromServerTwo);
		// System.out.println(strReplyFromServerThree);
		// System.out.println(strReplyFromServerFour);

	}

	private static void fnOpenUDPReplicaManagerfour() throws SocketException {
		// TODO Auto-generated method stub
		DatagramSocket dUDPSocket = new DatagramSocket(8004);

		System.out.println("replica manager 4 is running");
		while (true) {
			try {
				byte[] receiveData = new byte[510];
				byte[] sendData = new byte[500];
				DatagramPacket receivePacket = new DatagramPacket(receiveData,
						receiveData.length);
				dUDPSocket.receive(receivePacket);
				String strRequest = new String(trim(receivePacket.getData()));
				// System.out.println(strRequest);

				InetAddress IPAddress = receivePacket.getAddress();
				int iPort = receivePacket.getPort();

				System.out.println("fron one -- " + strRequest);

				sendData = ("fron four -- " + strRequest).getBytes();
				DatagramPacket sendPacket = new DatagramPacket(sendData,
						sendData.length, IPAddress, iPort);
				dUDPSocket.send(sendPacket);

			} catch (Exception ex) {
				ex.printStackTrace();
			}
		}
	}

	private static void fnOpenUDPReplicaManagerthree() throws SocketException {
		// TODO Auto-generated method stub
		DatagramSocket dUDPSocket = new DatagramSocket(8003);

		System.out.println("replica manager 3 is running");
		while (true) {
			try {
				byte[] receiveData = new byte[510];
				byte[] sendData = new byte[500];
				DatagramPacket receivePacket = new DatagramPacket(receiveData,
						receiveData.length);
				dUDPSocket.receive(receivePacket);
				String strRequest = new String(trim(receivePacket.getData()));
				// System.out.println(strRequest);

				InetAddress IPAddress = receivePacket.getAddress();
				int iPort = receivePacket.getPort();

				sendData = ("fron three -- " + strRequest).getBytes();
				DatagramPacket sendPacket = new DatagramPacket(sendData,
						sendData.length, IPAddress, iPort);
				dUDPSocket.send(sendPacket);

			} catch (Exception ex) {
				ex.printStackTrace();
			}
		}

	}

	private static void fnOpenUDPReplicaManagertwo() throws SocketException {
		// TODO Auto-generated method stub
		DatagramSocket dUDPSocket = new DatagramSocket(8002);

		System.out.println("replica manager 2 is running");
		while (true) {
			try {
				byte[] receiveData = new byte[510];
				byte[] sendData = new byte[500];
				DatagramPacket receivePacket = new DatagramPacket(receiveData,
						receiveData.length);
				dUDPSocket.receive(receivePacket);
				String strRequest = new String(trim(receivePacket.getData()));
				// System.out.println(strRequest);

				InetAddress IPAddress = receivePacket.getAddress();
				int iPort = receivePacket.getPort();

				sendData = ("fron two -- " + strRequest).getBytes();
				DatagramPacket sendPacket = new DatagramPacket(sendData,
						sendData.length, IPAddress, iPort);
				dUDPSocket.send(sendPacket);

			} catch (Exception ex) {
				ex.printStackTrace();
			}
		}

	}

	private static void fnOpenUDPReplicaManagerOne() throws SocketException {
		// TODO Auto-generated method stub
		DatagramSocket dUDPSocket = new DatagramSocket(8001);

		System.out.println("replica manager 1 is running");
		while (true) {
			try {
				byte[] receiveData = new byte[510];
				byte[] sendData = new byte[500];
				DatagramPacket receivePacket = new DatagramPacket(receiveData,
						receiveData.length);
				dUDPSocket.receive(receivePacket);
				String strRequest = new String(trim(receivePacket.getData()));
				// System.out.println(strRequest);

				InetAddress IPAddress = receivePacket.getAddress();
				int iPort = receivePacket.getPort();

				sendData = ("fron one -- " + strRequest).getBytes();
				DatagramPacket sendPacket = new DatagramPacket(sendData,
						sendData.length, IPAddress, iPort);
				dUDPSocket.send(sendPacket);

			} catch (Exception ex) {
				ex.printStackTrace();
			}
		}

	}

	static byte[] trim(byte[] bytes) {
		int i = bytes.length - 1;
		while (i >= 0 && bytes[i] == 0) {
			--i;
		}

		return Arrays.copyOf(bytes, i + 1);
	}

}
