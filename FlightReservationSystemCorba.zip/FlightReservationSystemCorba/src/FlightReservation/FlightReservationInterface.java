package FlightReservation;

/**
 * Interface definition: FlightReservationInterface.
 * 
 * @author OpenORB Compiler
 */
public interface FlightReservationInterface extends FlightReservationInterfaceOperations, org.omg.CORBA.Object, org.omg.CORBA.portable.IDLEntity
{
}
