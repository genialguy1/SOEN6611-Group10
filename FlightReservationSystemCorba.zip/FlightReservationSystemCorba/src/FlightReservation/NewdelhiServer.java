package FlightReservation;

import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.text.ParseException;
import java.util.HashMap;

import org.omg.CORBA.ORBPackage.InvalidName;
import org.omg.PortableServer.POA;
import org.omg.PortableServer.POAHelper;
import org.omg.PortableServer.POAManagerPackage.AdapterInactive;
import org.omg.PortableServer.POAPackage.ObjectNotActive;
import org.omg.PortableServer.POAPackage.ServantAlreadyActive;
import org.omg.PortableServer.POAPackage.WrongPolicy;

import com.sun.corba.se.internal.iiop.ORB;

public class NewdelhiServer implements Runnable {

	static FlightReservationImplementation objFlightReservationImpl = null;
	
	public NewdelhiServer(HashMap<String, CustomerDetails> c,
			HashMap<String, FlightDetails> f) throws Exception {

		this();
		objFlightReservationImpl.reinstate(c, f);

	}

	public NewdelhiServer() {
		try {
			String[] args = null;
			org.omg.CORBA.ORB orb = ORB.init(args, null);
			POA rootPOA = POAHelper.narrow(orb
					.resolve_initial_references("RootPOA"));

			objFlightReservationImpl = new FlightReservationImplementation();
			objFlightReservationImpl.hmFlightDetails = objFlightReservationImpl.fnAddDefaultFlightsFromNewdelhi();
			
			byte[] id = rootPOA.activate_object(objFlightReservationImpl);
			org.omg.CORBA.Object ref = rootPOA.id_to_reference(id);

			String ior = orb.object_to_string(ref);
			// System.out.println(ior);

			PrintWriter file = new PrintWriter("NewdelhiServer.txt");
			file.println(ior);
			file.close();

			System.out.println("NewDelhi Flight Booking Server Running...");
			rootPOA.the_POAManager().activate();
		} catch (Exception ex) {
			ex.printStackTrace();
		}

	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		try {
			objFlightReservationImpl.fnOpenUDPServer(8000, "ndl");
			// new ReplicaManager().fnHearBeatToAllServers();

		} catch (Exception e) {
			System.out.println("Exception in Montreal Server: " + e);
		}

	}

	public static void main(String[] args) throws InvalidName,
			ServantAlreadyActive, WrongPolicy, ObjectNotActive,
			FileNotFoundException, AdapterInactive, ParseException {
		// TODO Auto-generated method stub
		
		NewdelhiServer ndl = new NewdelhiServer();
		Thread t2 = new Thread(ndl);
		t2.start();

		// orb.run();

	}
}
