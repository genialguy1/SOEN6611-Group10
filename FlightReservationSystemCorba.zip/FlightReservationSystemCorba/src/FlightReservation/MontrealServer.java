package FlightReservation;

import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.text.ParseException;
import java.util.HashMap;

import org.omg.CORBA.ORBPackage.InvalidName;
import org.omg.PortableServer.POA;
import org.omg.PortableServer.POAHelper;
import org.omg.PortableServer.POAManagerPackage.AdapterInactive;
import org.omg.PortableServer.POAPackage.ObjectNotActive;
import org.omg.PortableServer.POAPackage.ServantAlreadyActive;
import org.omg.PortableServer.POAPackage.WrongPolicy;

import com.sun.corba.se.internal.iiop.ORB;

public class MontrealServer implements Runnable {

	static FlightReservationImplementation objFlightReservationImpl = null;

	public MontrealServer() throws ParseException, InvalidName,
			ObjectNotActive, WrongPolicy, ServantAlreadyActive,
			FileNotFoundException, AdapterInactive {
		// TODO Auto-generated method stub
		objFlightReservationImpl = new FlightReservationImplementation();

		objFlightReservationImpl.hmFlightDetails = objFlightReservationImpl
				.fnAddDefaultFlightsFromMontreal();

		String[] args = null;
		org.omg.CORBA.ORB orb = ORB.init(args, null);
		POA rootPOA = POAHelper.narrow(orb
				.resolve_initial_references("RootPOA"));

		byte[] id = rootPOA.activate_object(objFlightReservationImpl);
		org.omg.CORBA.Object ref = rootPOA.id_to_reference(id);

		String ior = orb.object_to_string(ref);
		// System.out.println(ior);

		PrintWriter file = new PrintWriter("MontrealServer.txt");
		file.println(ior);
		file.close();

		System.out.println("Montreal Flight Booking Server Running...");
		rootPOA.the_POAManager().activate();

		// orb.run();

	}

	public MontrealServer(HashMap<String, CustomerDetails> c,
			HashMap<String, FlightDetails> f) throws Exception {

		this();
		objFlightReservationImpl.reinstate(c, f);

	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		try {
			objFlightReservationImpl.fnOpenUDPServer(7000, "mtl");
			// new ReplicaManager().fnHearBeatToAllServers();

		} catch (Exception e) {
			System.out.println("Exception in Montreal Server: " + e);
		}

	}

	public void fnAssignHashMap(
			HashMap<String, CustomerDetails> hmBookedTicket,
			HashMap<String, FlightDetails> hmFlightList) {

		objFlightReservationImpl.hmCustomerDetails = hmBookedTicket;
		objFlightReservationImpl.hmFlightDetails = hmFlightList;

	}

	public static void main(String args[]) {

		MontrealServer mtl = null;
		try {
			mtl = new MontrealServer();
		} catch (InvalidName | ObjectNotActive | WrongPolicy
				| ServantAlreadyActive | FileNotFoundException
				| AdapterInactive | ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Thread t1 = new Thread(mtl);
		t1.start();
	}
}
