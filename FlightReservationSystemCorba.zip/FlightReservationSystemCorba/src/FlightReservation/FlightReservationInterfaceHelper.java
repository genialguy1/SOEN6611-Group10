package FlightReservation;

/** 
 * Helper class for : FlightReservationInterface
 *  
 * @author OpenORB Compiler
 */ 
public class FlightReservationInterfaceHelper
{
    /**
     * Insert FlightReservationInterface into an any
     * @param a an any
     * @param t FlightReservationInterface value
     */
    public static void insert(org.omg.CORBA.Any a, FlightReservation.FlightReservationInterface t)
    {
        a.insert_Object(t , type());
    }

    /**
     * Extract FlightReservationInterface from an any
     *
     * @param a an any
     * @return the extracted FlightReservationInterface value
     */
    public static FlightReservation.FlightReservationInterface extract( org.omg.CORBA.Any a )
    {
        if ( !a.type().equivalent( type() ) )
        {
            throw new org.omg.CORBA.MARSHAL();
        }
        try
        {
            return FlightReservation.FlightReservationInterfaceHelper.narrow( a.extract_Object() );
        }
        catch ( final org.omg.CORBA.BAD_PARAM e )
        {
            throw new org.omg.CORBA.MARSHAL(e.getMessage());
        }
    }

    //
    // Internal TypeCode value
    //
    private static org.omg.CORBA.TypeCode _tc = null;

    /**
     * Return the FlightReservationInterface TypeCode
     * @return a TypeCode
     */
    public static org.omg.CORBA.TypeCode type()
    {
        if (_tc == null) {
            org.omg.CORBA.ORB orb = org.omg.CORBA.ORB.init();
            _tc = orb.create_interface_tc( id(), "FlightReservationInterface" );
        }
        return _tc;
    }

    /**
     * Return the FlightReservationInterface IDL ID
     * @return an ID
     */
    public static String id()
    {
        return _id;
    }

    private final static String _id = "IDL:FlightReservation/FlightReservationInterface:1.0";

    /**
     * Read FlightReservationInterface from a marshalled stream
     * @param istream the input stream
     * @return the readed FlightReservationInterface value
     */
    public static FlightReservation.FlightReservationInterface read(org.omg.CORBA.portable.InputStream istream)
    {
        return(FlightReservation.FlightReservationInterface)istream.read_Object(FlightReservation._FlightReservationInterfaceStub.class);
    }

    /**
     * Write FlightReservationInterface into a marshalled stream
     * @param ostream the output stream
     * @param value FlightReservationInterface value
     */
    public static void write(org.omg.CORBA.portable.OutputStream ostream, FlightReservation.FlightReservationInterface value)
    {
        ostream.write_Object((org.omg.CORBA.portable.ObjectImpl)value);
    }

    /**
     * Narrow CORBA::Object to FlightReservationInterface
     * @param obj the CORBA Object
     * @return FlightReservationInterface Object
     */
    public static FlightReservationInterface narrow(org.omg.CORBA.Object obj)
    {
        if (obj == null)
            return null;
        if (obj instanceof FlightReservationInterface)
            return (FlightReservationInterface)obj;

        if (obj._is_a(id()))
        {
            _FlightReservationInterfaceStub stub = new _FlightReservationInterfaceStub();
            stub._set_delegate(((org.omg.CORBA.portable.ObjectImpl)obj)._get_delegate());
            return stub;
        }

        throw new org.omg.CORBA.BAD_PARAM();
    }

    /**
     * Unchecked Narrow CORBA::Object to FlightReservationInterface
     * @param obj the CORBA Object
     * @return FlightReservationInterface Object
     */
    public static FlightReservationInterface unchecked_narrow(org.omg.CORBA.Object obj)
    {
        if (obj == null)
            return null;
        if (obj instanceof FlightReservationInterface)
            return (FlightReservationInterface)obj;

        _FlightReservationInterfaceStub stub = new _FlightReservationInterfaceStub();
        stub._set_delegate(((org.omg.CORBA.portable.ObjectImpl)obj)._get_delegate());
        return stub;

    }

}
