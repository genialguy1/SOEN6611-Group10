package FlightReservation;

import java.io.Serializable;

public class CustomerDetails implements java.io.Serializable{
	String strCustomerFirstName;
	String strCustomerLastName;
	String strCustomerAddress;
	String dCustomerPhoneNumber;

	String strsBookingID;
	String strClassBooked;

	public String toString() {
		return String
				.format("Customer[First Name: %s, Last Name: %s ,Address :%s , phone :%s, Booking ID: %s]",
						strCustomerFirstName, strCustomerLastName,
						strCustomerAddress, dCustomerPhoneNumber, strsBookingID);
	}
}
