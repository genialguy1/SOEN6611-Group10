package FlightReservation;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.text.ParseException;
import java.util.Date;
import java.util.Scanner;
import java.util.logging.FileHandler;
import java.util.logging.Logger;

import org.omg.CORBA.ORB;

public class FlightReservationClient {

	// declaration
	public static String strCustomerFirstName;
	public static String strCustomerLastName;
	public static String strCustomerAddress;
	public static String dCustomerPhoneNumber;
	public static String strFlightSource;
	public static String strFlightDestination;
	public static String strFlightClass;
	public static String strFlightDate;

	public static String strEditField;
	public static String strNewValue;
	public static String strFlightId;
	public static String strManagerId;

	static FlightReservationInterface iMontrealFlights = null;
	static FlightReservationInterface iNewdelhiFlights = null;
	static FlightReservationInterface iWashingtonFlights = null;
	static FlightReservationInterface iFlightReservation = null;

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		ORB orb = ORB.init(args, null);

		// Montreal server
		BufferedReader brMontrealServer = new BufferedReader(new FileReader(
				"MontrealServer.txt"));
		String iorMontreal = brMontrealServer.readLine();
		brMontrealServer.close();
		org.omg.CORBA.Object objMontrealCorba = orb
				.string_to_object(iorMontreal);
		iMontrealFlights = FlightReservationInterfaceHelper
				.narrow(objMontrealCorba);

		BufferedReader brNewdelhiServer = new BufferedReader(new FileReader(
				"NewdelhiServer.txt"));
		String iorNewdelhi = brNewdelhiServer.readLine();
		brMontrealServer.close();
		org.omg.CORBA.Object objNewdelhiCorba = orb
				.string_to_object(iorNewdelhi);
		iNewdelhiFlights = FlightReservationInterfaceHelper
				.narrow(objNewdelhiCorba);

		BufferedReader brWashingtonServer = new BufferedReader(new FileReader(
				"WashingtonServer.txt"));
		String iorWashington = brWashingtonServer.readLine();
		brMontrealServer.close();
		org.omg.CORBA.Object objWashingtonCorba = orb
				.string_to_object(iorWashington);
		iWashingtonFlights = FlightReservationInterfaceHelper
				.narrow(objWashingtonCorba);

		Integer choice = 0;
		while (choice < 3) {
			System.out.println("Welcome to Flight reservation");
			System.out.println("Whom you want to login as:");
			System.out.println("1. Customer");
			System.out.println("2. Manager");
			System.out.println("3. Exit");

			Scanner in = new Scanner(System.in);
			choice = in.nextInt();

			if (choice == 1) {
				{
					try {
						fnCustomer();
					} catch (ParseException e) {
						e.printStackTrace();
					}
				}
			} else if (choice == 2)
				fnManager();
		}
	}

	private static void fnCustomer() throws ParseException, IOException {
		// TODO Auto-generated method stub
		Integer choice1 = 0;
		while (choice1 < 2) {
			System.out.println("Select a choice from below:");
			System.out.println("1. Book a flight");
			System.out.println("2. ExitS");

			Scanner in1 = new Scanner(System.in);
			choice1 = in1.nextInt();

			if (choice1 == 1) {
				/*
				 * int i = 1; Set set = hmFlightDetails.entrySet();
				 * java.util.Iterator iterator = set.iterator(); while
				 * (iterator.hasNext()) { Map.Entry mentry = (Map.Entry)
				 * iterator.next(); System.out.println(i + ". " +
				 * mentry.getValue()); i++; }
				 */

				fnGetCustomerDetails();
				// fnGetCustomerDetailsTest();
				// System.out.println("method enter");

				switch (strFlightSource.toLowerCase()) {
				case "mtl":
					iFlightReservation = iMontrealFlights;
					break;
				case "ndl":
					iFlightReservation = iNewdelhiFlights;
					break;
				case "wht":
					iFlightReservation = iWashingtonFlights;
					break;
				}
				try {

					Runnable t1 = new Runnable() {
						public void run() {
							try {
								// fnCustomer();
								String strStatus = iFlightReservation
										.fnBookFlight(strCustomerFirstName,
												strCustomerLastName,
												strCustomerAddress,
												dCustomerPhoneNumber,
												strFlightSource,
												strFlightDestination,
												strFlightDate, strFlightClass);
								System.out.println(strStatus + "\n");
								fnTracelog(strStatus);
								fnTracelog(strCustomerFirstName
										+ strCustomerLastName
										+ strCustomerAddress
										+ dCustomerPhoneNumber
										+ strFlightSource
										+ strFlightDestination + strFlightClass
										+ strFlightDate);
							} catch (Exception e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
						}
					};
					Runnable t2 = new Runnable() {
						public void run() {
							try {
								// fnCustomer();
								String strStatus = iFlightReservation
										.fnBookFlight(strCustomerFirstName,
												strCustomerLastName,
												strCustomerAddress,
												dCustomerPhoneNumber,
												strFlightSource,
												strFlightDestination,
												strFlightDate, strFlightClass);
								System.out.println(strStatus + "\n");
								fnTracelog(strStatus);
								fnTracelog(strCustomerFirstName
										+ strCustomerLastName
										+ strCustomerAddress
										+ dCustomerPhoneNumber
										+ strFlightSource
										+ strFlightDestination + strFlightClass
										+ strFlightDate);
							} catch (Exception e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
						}
					};
					Runnable t3 = new Runnable() {
						public void run() {
							try {
								// fnCustomer();
								String strStatus = iFlightReservation
										.fnBookFlight(strCustomerFirstName,
												strCustomerLastName,
												strCustomerAddress,
												dCustomerPhoneNumber,
												strFlightSource,
												strFlightDestination,
												strFlightDate, strFlightClass);
								System.out.println(strStatus + "\n");
								fnTracelog(strStatus);
								fnTracelog(strCustomerFirstName
										+ strCustomerLastName
										+ strCustomerAddress
										+ dCustomerPhoneNumber
										+ strFlightSource
										+ strFlightDestination + strFlightClass
										+ strFlightDate);
							} catch (Exception e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
						}
					};
					Runnable t4 = new Runnable() {
						public void run() {
							try {
								// fnCustomer();
								String strStatus = iFlightReservation
										.fnBookFlight(strCustomerFirstName,
												strCustomerLastName,
												strCustomerAddress,
												dCustomerPhoneNumber,
												strFlightSource,
												strFlightDestination,
												strFlightDate, strFlightClass);
								System.out.println(strStatus + "\n");
								fnTracelog(strStatus);
								fnTracelog(strCustomerFirstName
										+ strCustomerLastName
										+ strCustomerAddress
										+ dCustomerPhoneNumber
										+ strFlightSource
										+ strFlightDestination + strFlightClass
										+ strFlightDate);
							} catch (Exception e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
						}
					};

					new Thread(t1).start();
					// new Thread(t2).start();
					// new Thread(t3).start();
					// new Thread(t4).start();

				} catch (Exception e) {
					// TODO Auto-generated catch block
					System.out
							.println("Error while booking flight ticket. please try again later"
									+ e.toString());
					e.printStackTrace();

					fnTracelog("Error while booking flight ticket"
							+ e.toString());
				}
			}
		}
	}

	private static void fnGetCustomerDetails() throws ParseException {
		// TODO Auto-generated method stub
		Scanner in = new Scanner(System.in);

		System.out.println("Enter Customer First Name:");
		strCustomerFirstName = in.nextLine();
		System.out.println("Enter Customer Last Name:");
		strCustomerLastName = in.nextLine();
		System.out.println("Enter Customer Address:");
		strCustomerAddress = in.nextLine();
		System.out.println("Enter Customer Phone Number:");
		dCustomerPhoneNumber = in.nextLine();
		System.out.println("Enter Source Location(MTL/NDL/WHT):");
		strFlightSource = in.nextLine();
		System.out.println("Enter Destination Location(MTL/NDL/WHT):");
		strFlightDestination = in.nextLine();
		System.out.println("Enter Flight Class(Eco/Pre):");
		strFlightClass = in.nextLine();
		System.out.println("Enter Flight date:");
		// DateFormat df = new SimpleDateFormat("dd/MM/yyyy");
		strFlightDate = in.nextLine();
	}

	private static void fnGetCustomerDetailsTest() throws ParseException,
			IOException {
		// TODO Auto-generated method stub
		Scanner in = new Scanner(System.in);

		System.out.println("Enter Customer First Name:");
		strCustomerFirstName = "goutham";
		System.out.println("Enter Customer Last Name:");
		strCustomerLastName = "raj";
		System.out.println("Enter Customer Address:");
		strCustomerAddress = "montreal";
		System.out.println("Enter Customer Phone Number:");
		dCustomerPhoneNumber = "2222";
		System.out.println("Enter Source Location(MTL/NDL/WHT):");
		strFlightSource = "mtl";
		System.out.println("Enter Destination Location(MTL/NDL/WHT):");
		strFlightDestination = "ndl";
		System.out.println("Enter Flight Class(Eco/Pre):");
		strFlightClass = "eco";
		System.out.println("Enter Flight date:");
		// DateFormat df = new SimpleDateFormat("dd/MM/yyyy");
		strFlightDate = "10/11/2016";

		// fnTracelog(strCustomerAddress);
	}

	private static void fnManager() throws IOException {
		// TODO Auto-generated method stub
		Integer choice = 0;
		Scanner in = new Scanner(System.in);

		System.out.println("Enter manager ID");

		strManagerId = in.nextLine();

		if (strManagerId.length() >= 4) {
			if (strManagerId.substring(0, 3).equalsIgnoreCase("mtl")
					|| strManagerId.substring(0, 3).equalsIgnoreCase("ndl")
					|| strManagerId.substring(0, 3).equalsIgnoreCase("wst")) {
				System.out.println("Welcome manager");
				switch (strManagerId.substring(0, 3)) {
				case "mtl":
					iFlightReservation = iMontrealFlights;
					break;
				case "ndl":
					iFlightReservation = iNewdelhiFlights;
					break;
				case "wht":
					iFlightReservation = iWashingtonFlights;
					break;
				}

				while (choice < 4) {
					System.out.println("Select a choice from below:");
					System.out.println("1. Get Flight count");
					System.out.println("2. Edit Flight records");
					System.out.println("3. Transfer Flight details");
					System.out.println("4. Exit");

					choice = in.nextInt();
					fnTracelog("Manager ID: " + strManagerId);

					if (choice == 1) {
						String strTotalcount = iFlightReservation
								.fnGetBookedFlightCount(strManagerId.substring(
										0, 3));
						System.out.println(strTotalcount);
						fnTracelog("Manager checked for total count");
					} else if (choice == 2) {
						fnEditFlightDetails();
						fnTracelog("flight edited by manager");
					} else if (choice == 3) {
						fnUpdateFlightRecord();
					}
				}
			} else {
				fnTracelog("Authroization failed" + strManagerId);
				System.out.println("Authroization fail");
			}
		} else {
			fnTracelog("Authroization failed" + strManagerId);
			System.out.println("Authroization fail");
		}
	}

	private static void fnUpdateFlightRecord() {
		// TODO Auto-generated method stub
		Scanner in = new Scanner(System.in);

		System.out.println("Enter the booking ID");
		String strBookingID = in.nextLine();

		System.out.println("Enter new source");
		String strNewSource = in.nextLine();

		System.out.println("Enter new date");
		String strNewDate = in.nextLine();

		try {
			System.out.println(iFlightReservation.fnTransferFlightDetails(
					strBookingID, strNewSource, strNewDate));
		} catch (Exception ex) {

		}
	}

	private static void fnEditFlightDetails() {
		// TODO Auto-generated method stub
		Scanner in = new Scanner(System.in);

		System.out.println("Enter Flight ID:");
		strFlightId = in.nextLine();
		System.out
				.println("Enter Field (source/destination/flightdate/economyseats/premiumseats)");
		strEditField = in.nextLine();
		System.out.println("Enter new value");
		strNewValue = in.nextLine();

		try {
			String strStatus = iFlightReservation.fnEditFlightRecord(
					strManagerId, strFlightId, strEditField, strNewValue,"edit");
			System.out.println(strStatus);
			fnTracelog(strStatus + "By manager");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			System.out
					.println("Error while editing the flight record. try again later..."
							+ e.getStackTrace());
			fnTracelog("error while editing flight by manager");
		}

	}

	public static void fnTracelog(String strLog) {
		try {
			Logger logger = Logger.getLogger("Flight Reservation Log");
			// FileHandler fh;
			FileHandler fileHandler = new FileHandler(
					"F:/log/FlightReservation.log", true);
			logger.addHandler(fileHandler);

			logger.info(strLog + "\n");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("error in trace");
		}

	}

}
