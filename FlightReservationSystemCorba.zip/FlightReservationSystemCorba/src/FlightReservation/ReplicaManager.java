package FlightReservation;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.util.Arrays;
import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class ReplicaManager extends Thread implements Runnable {

	private static boolean flag = true;
	static org.omg.CORBA.ORB orb = null;
	static FlightReservationImplementation objFlightReservationImpl = null;
	static HashMap<String, CustomerDetails> hmBookedCustomer = new HashMap<String, CustomerDetails>();
	static HashMap<String, FlightDetails> hmFlightDetails = new HashMap<String, FlightDetails>();

	public static void main(String[] args) {
		fnHeartBeatToAllServers(args);
	}

	public static void fnHeartBeatToAllServers(String[] args) {

		while (true) {

			try {
				fnSendheartBeatToCity(7000); // montreal heart beat check
			} catch (Exception ex) {
				fnRestartServer("mtl", args);
			}
			try {
				fnSendheartBeatToCity(8000); // new delhi heart beat check
			} catch (Exception ex) {
				fnRestartServer("ndl", args);
			}
			try {
				fnSendheartBeatToCity(9000); // washington heart beat check
			} catch (Exception ex) {
				fnRestartServer("wst", args);
			}
			try {
				sleep(3000);
			} catch (Exception ex) {
				ex.printStackTrace();
			}
		}
	}

	private static void fnSendheartBeatToCity(int iPortNumber) throws Exception {
		// TODO Auto-generated method stub
		String strReplyFromServer = "";
		byte[] bReceiveData = new byte[10];
		byte[] bSendData = new byte[10];
		DatagramPacket dpSendPacket = null;
		DatagramSocket dgSocket = null;
		InetAddress ipHostAddress = null;

		try {
			ipHostAddress = InetAddress.getByName("localhost");
			dgSocket = new DatagramSocket();
			dgSocket.setSoTimeout(5000);
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		bSendData = "heart".getBytes();

		try {
			dpSendPacket = new DatagramPacket(bSendData, bSendData.length,
					ipHostAddress, iPortNumber);
			dgSocket.send(dpSendPacket);
			DatagramPacket dpReceivePacket = new DatagramPacket(bReceiveData,
					bReceiveData.length);
			dgSocket.receive(dpReceivePacket);
			strReplyFromServer = new String(trim(dpReceivePacket.getData()),
					"UTF-8");
			System.out.println(strReplyFromServer);
		} catch (Exception e) {
			System.out.println("Error. Heartbeat not received");
			throw e;
		}
	}

	static byte[] trim(byte[] bytes) {
		int i = bytes.length - 1;
		while (i >= 0 && bytes[i] == 0) {
			--i;
		}
		return Arrays.copyOf(bytes, i + 1);
	}

	public static void fnRestartServer(String strLocation, String[] args) {
		switch (strLocation.toLowerCase()) {
		case "mtl":
			try {
				fnRestoreServers("mtl");
				fnRestoreFlight("mtl");
				MontrealServer mtl = new MontrealServer(hmBookedCustomer,
						hmFlightDetails);
				Thread t1 = new Thread(mtl);
				t1.start();

				fnHeartBeatToAllServers(new String[4]);
				// objFlightReservationImpl.fnOpenUDPServer(7000, "mtl");
			} catch (Exception ex) {
				System.out.println(ex);
			}
		case "ndl":
			try {
				fnRestoreServers("ndl");
				fnRestoreFlight("mtl");

				NewdelhiServer mtl = new NewdelhiServer(hmBookedCustomer,
						hmFlightDetails);
				Thread t2 = new Thread(mtl);
				t2.start();

				fnHeartBeatToAllServers(new String[4]);
				// objFlightReservationImpl.fnOpenUDPServer(7000, "mtl");
			} catch (Exception ex) {
				System.out.println(ex);
			}
		case "wst":
			try {
				fnRestoreServers("wst");
				fnRestoreFlight("mtl");

				WashingtonServer wst = new WashingtonServer(hmBookedCustomer,
						hmFlightDetails);
				Thread t3 = new Thread(wst);
				t3.start();

				fnHeartBeatToAllServers(new String[4]);
				// objFlightReservationImpl.fnOpenUDPServer(7000, "mtl");
			} catch (Exception ex) {
				System.out.println(ex);
			}

		}
	}

	public static void fnRestartAllServer() {
		String[] args = new String[4];
		fnRestartServer("mtl", args);
		fnRestartServer("ndl", args);
		fnRestartServer("wst", args);
	}

	public static void fnRestoreServers(String strLocation) {
		int iPort = 0;
		switch (strLocation.toLowerCase()) {
		case "mtl":
			iPort = 7001;
			break;
		case "ndl":
			iPort = 8001;
			break;
		case "wst":
			iPort = 9001;
			break;
		}

		try {
			Integer count = 0;
			String strng = null;
			byte[] buf = new byte[1024];
			byte[] sendData = new byte[1024];
			String sentence = null;
			sentence = "restore";
			sendData = sentence.getBytes();
			// sendData = sentence.getBytes();
			InetAddress aHost = InetAddress.getByName("localhost");
			DatagramSocket aSocket = new DatagramSocket();
			DatagramPacket sendPacket1 = new DatagramPacket(sendData,
					sendData.length, aHost, iPort);
			aSocket.send(sendPacket1);

			System.out.println("Source Port" + sendPacket1.getPort());
			byte[] buffer = new byte[100000];
			DatagramPacket packet = new DatagramPacket(buffer, buffer.length);
			aSocket.receive(packet);
			Object o = (Object) packet;
			ByteArrayInputStream byteStream = new ByteArrayInputStream(buffer);
			ObjectInputStream is = new ObjectInputStream(
					new BufferedInputStream(byteStream));
			Object o1 = is.readObject();
			hmBookedCustomer = (HashMap<String, CustomerDetails>) o1;
			is.close();

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private static void fnRestoreFlight(String strLocation) {
		int iPort = 0;
		switch (strLocation.toLowerCase()) {
		case "mtl":
			iPort = 7001;
			break;
		case "ndl":
			iPort = 8001;
			break;
		case "wst":
			iPort = 9001;
			break;
		}

		try {
			Integer count = 0;
			String strng = null;
			byte[] buf = new byte[1024];
			byte[] sendData = new byte[1024];
			String sentence = null;
			sentence = "restoreflight";
			sendData = sentence.getBytes();
			// sendData = sentence.getBytes();
			InetAddress aHost = InetAddress.getByName("localhost");
			DatagramSocket aSocket = new DatagramSocket();
			DatagramPacket sendPacket1 = new DatagramPacket(sendData,
					sendData.length, aHost, iPort);
			aSocket.send(sendPacket1);

			System.out.println("Source Port" + sendPacket1.getPort());
			byte[] buffer = new byte[100000];
			DatagramPacket packet = new DatagramPacket(buffer, buffer.length);
			aSocket.receive(packet);
			Object o = (Object) packet;
			ByteArrayInputStream byteStream = new ByteArrayInputStream(buffer);
			ObjectInputStream is = new ObjectInputStream(
					new BufferedInputStream(byteStream));
			Object o1 = is.readObject();
			hmFlightDetails = (HashMap<String, FlightDetails>) o1;
			is.close();

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
}
