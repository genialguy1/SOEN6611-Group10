package FlightReservation;

import java.io.BufferedReader;
import java.io.FileReader;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
//import net.rudp.ReliableServerSocket;
//import net.rudp.ReliableSocket;
import java.net.InetAddress;
import java.util.Arrays;
import java.util.HashMap;

import org.omg.CORBA.ORB;

import sun.net.InetAddressCachePolicy;

public class ReplicaParser {

	public static String strCustomerFirstName;
	public static String strCustomerLastName;
	public static String strCustomerAddress;
	public static String dCustomerPhoneNumber;
	public static String strFlightSource;
	public static String strFlightDestination;
	public static String strFlightClass;
	public static String strFlightDate;

	public static String strEditField;
	public static String strNewValue;
	public static String strFlightId;

	public static String strManagerId;

	private static String strBookingId;
	private static String strNewSource;
	private static String strNewDate;

	static FlightReservationInterface iMontrealFlights = null;
	static FlightReservationInterface iNewdelhiFlights = null;
	static FlightReservationInterface iWashingtonFlights = null;
	static FlightReservationInterface iFlightReservation = null;

	static HashMap<Integer, String> hmSequenceList = null;

	static String[] strReqData = null;

	static int iSequencer = 1;

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		hmSequenceList = new HashMap<Integer, String>();

		fnRegisterORB(args);

		fnGetInputFromSequencer();

	}

	public static void fnRegisterORB(String[] args) {
		ORB orb = ORB.init(args, null);

		try {
			// Montreal server
			BufferedReader brMontrealServer = new BufferedReader(
					new FileReader("MontrealServer.txt"));
			String iorMontreal = brMontrealServer.readLine();
			brMontrealServer.close();
			org.omg.CORBA.Object objMontrealCorba = orb
					.string_to_object(iorMontreal);
			iMontrealFlights = FlightReservationInterfaceHelper
					.narrow(objMontrealCorba);

			// Newdelhi server
			BufferedReader brNewdelhiServer = new BufferedReader(
					new FileReader("NewdelhiServer.txt"));
			String iorNewdelhi = brNewdelhiServer.readLine();
			brMontrealServer.close();
			org.omg.CORBA.Object objNewdelhiCorba = orb
					.string_to_object(iorNewdelhi);
			iNewdelhiFlights = FlightReservationInterfaceHelper
					.narrow(objNewdelhiCorba);

			// Washington server
			BufferedReader brWashingtonServer = new BufferedReader(
					new FileReader("WashingtonServer.txt"));
			String iorWashington = brWashingtonServer.readLine();
			brMontrealServer.close();
			org.omg.CORBA.Object objWashingtonCorba = orb
					.string_to_object(iorWashington);
			iWashingtonFlights = FlightReservationInterfaceHelper
					.narrow(objWashingtonCorba);
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	public static void fnGetInputFromSequencer() {
		String strReplyFromSequencer = "";
		byte[] bReceiveData = null;
		byte[] bSendData = new byte[10];
		DatagramPacket dpSendPacket = null;
		DatagramSocket dgSocket = null;
		// InetAddress ipHostAddress = null;

		try {
			// ipHostAddress = InetAddress.getByName("localhost");
			dgSocket = new DatagramSocket(9011);
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		bSendData = "got it".getBytes();
		String strStatus = "";
		boolean flag = false;

		for (;;) {
			strStatus = "";
			try {
				InetAddress aHost1 = InetAddress.getByName("192.168.0.139");

				bReceiveData = new byte[1024];
				System.out.println("parser running");
				DatagramPacket dpReceivePacket = new DatagramPacket(
						bReceiveData, bReceiveData.length);
				dgSocket.receive(dpReceivePacket);
				strReplyFromSequencer = new String(
						trim(dpReceivePacket.getData()), "UTF-8");
				System.out.println(strReplyFromSequencer);

				String[] req = strReplyFromSequencer.split("]");

				String strRequestMessage = "";
				// System.out.println(req[0]);
				// System.out.println(req[1]);
				hmSequenceList.put(Integer.parseInt(req[0]), req[1]);

				strRequestMessage = hmSequenceList.get(iSequencer);
				System.out.println(strRequestMessage);

				// strRequestMessage =
				// "bookflight[goutham,raj,chennai,12345,MTL,NDL,10/11/2016,eco";

				if (strRequestMessage != null) {

					// split the req message and call the methods.

					strReqData = strRequestMessage.split("\\[");

					switch (strReqData[0].toLowerCase()) {
					case "bookflight":
						strStatus = fnBookFlight();
						break;
					case "getbookedcount":
						strStatus = fnGetBookedCount();
						break;
					case "transferflight":
						strStatus = fnTransferFlightRecord();
						break;
					case "editflight":
						strStatus = fnEditFlightRecords();
						break;
					case "createflights":
						strStatus = fnCreateFlights();
						break;
					}
					hmSequenceList.remove(iSequencer);

					iSequencer++;
					strStatus = "RM3:" + strStatus;
					System.out.println(strStatus);

					while (hmSequenceList.containsKey(iSequencer)) {
						strRequestMessage = hmSequenceList.get(iSequencer);
						if (strRequestMessage != null) {

							// split the req message and call the methods.

							strReqData = strRequestMessage.split("[");

							switch (strReqData[0].toLowerCase()) {
							case "bookflight":
								strStatus = fnBookFlight();
								break;
							case "getbookedcount":
								strStatus = fnGetBookedCount();
								break;
							case "transferflight":
								strStatus = fnTransferFlightRecord();
								break;
							case "editflight":
								strStatus = fnEditFlightRecords();
								break;
							case "createflights":
								strStatus = fnCreateFlights();
								break;
							}
							hmSequenceList.remove(iSequencer);

							iSequencer++;
							strStatus = "RM3:" + strStatus;
							System.out.println(strStatus);
						}
					}

				}

				DatagramPacket sendPacket12 = new DatagramPacket(
						strStatus.getBytes(), strStatus.getBytes().length,
						dpReceivePacket.getAddress(), 9812);

				/*
				 * InetAddress aHost1 = InetAddress.getByAddress(new
				 * byte[]{(byte) 192,(byte) 168,(byte)1,(byte)2}); dpSendPacket
				 * = new DatagramPacket(strStatus.getBytes(),
				 * strStatus.getBytes().length, aHost1, 9812);
				 */

				dgSocket.send(sendPacket12);
			} catch (Exception e) {
				e.printStackTrace();
				// throw e;
			}
		}
	}

	private static String fnCreateFlights() {
		// TODO Auto-generated method stub
		String[] strInput = strReqData[1].split(",");
		strFlightSource = strInput[1];
		strFlightDestination = strInput[2];
		strFlightDate = strInput[3];

		fnAssignServerObject(strFlightSource);

		return iFlightReservation.Createflights(strFlightSource,
				strFlightDestination, strFlightDate);

	}

	static String fnBookFlight() {
		String[] strInput = strReqData[1].split(",");
		strCustomerFirstName = strInput[0];
		strCustomerLastName = strInput[1];
		strCustomerAddress = strInput[2];
		dCustomerPhoneNumber = strInput[3];
		strFlightSource = strInput[4];
		strFlightDestination = strInput[5];
		strFlightDate = strInput[6];
		strFlightClass = strInput[7];

		fnAssignServerObject(strFlightSource);

		return iFlightReservation.fnBookFlight(strCustomerFirstName,
				strCustomerLastName, strCustomerAddress, dCustomerPhoneNumber,
				strFlightSource, strFlightDestination, strFlightDate,
				strFlightClass);
	}

	static String fnGetBookedCount() {
		fnAssignServerObject(strReqData[1]);
		try {
			return iFlightReservation.fnGetBookedFlightCount(strReqData[1]);
		} catch (Exception ex) {
			ex.printStackTrace();
			return "error";
		}
	}

	static String fnTransferFlightRecord() {
		String[] strInput = strReqData[1].split(",");
		strBookingId = strInput[0];
		strNewSource = strInput[1];
		strNewDate = strInput[2];

		fnAssignServerObject(strNewSource);

		try {
			return iFlightReservation.fnTransferFlightDetails(strBookingId,
					strNewSource, strNewDate);
		} catch (Exception ex) {
			ex.printStackTrace();
			return "error";
		}
	}

	static String fnEditFlightRecords() {
		String[] strInput = strReqData[1].split(",");
		strManagerId = strInput[0];
		strFlightId = strInput[1];
		strEditField = strInput[2];
		strNewValue = strInput[3];
		// strOption = strInput[4];

		fnAssignServerObject(strManagerId.substring(0, 3));

		System.out.println(strManagerId);
		System.out.println(strFlightId);
		System.out.println(strEditField);
		System.out.println(strNewValue);

		try {
			return iFlightReservation.fnEditFlightRecord(strManagerId,
					strFlightId, strEditField, strNewValue, strInput[4]);
		} catch (Exception ex) {
			ex.printStackTrace();
			return "error";
		}
	}

	static byte[] trim(byte[] bytes) {
		int i = bytes.length - 1;
		while (i >= 0 && bytes[i] == 0) {
			--i;
		}
		return Arrays.copyOf(bytes, i + 1);
	}

	static void fnAssignServerObject(String strSource) {
		switch (strSource.toLowerCase()) {
		case "mtl":
			// fnRegisterORB(null);
			iFlightReservation = iMontrealFlights;
			break;
		case "ndl":
			// fnRegisterORB(null);
			iFlightReservation = iNewdelhiFlights;
			break;
		case "wst":
			// fnRegisterORB(null);
			iFlightReservation = iWashingtonFlights;
			break;
		}
	}

}
