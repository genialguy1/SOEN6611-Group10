package FlightReservation;

/**
 * Interface definition: FlightReservationInterface.
 * 
 * @author OpenORB Compiler
 */
public abstract class FlightReservationInterfacePOA extends org.omg.PortableServer.Servant
        implements FlightReservationInterfaceOperations, org.omg.CORBA.portable.InvokeHandler
{
    public FlightReservationInterface _this()
    {
        return FlightReservationInterfaceHelper.narrow(_this_object());
    }

    public FlightReservationInterface _this(org.omg.CORBA.ORB orb)
    {
        return FlightReservationInterfaceHelper.narrow(_this_object(orb));
    }

    private static String [] _ids_list =
    {
        "IDL:FlightReservation/FlightReservationInterface:1.0"
    };

    public String[] _all_interfaces(org.omg.PortableServer.POA poa, byte [] objectId)
    {
        return _ids_list;
    }

    public final org.omg.CORBA.portable.OutputStream _invoke(final String opName,
            final org.omg.CORBA.portable.InputStream _is,
            final org.omg.CORBA.portable.ResponseHandler handler)
    {

        if (opName.equals("Createflights")) {
                return _invoke_Createflights(_is, handler);
        } else if (opName.equals("fnBookFlight")) {
                return _invoke_fnBookFlight(_is, handler);
        } else if (opName.equals("fnEditFlightRecord")) {
                return _invoke_fnEditFlightRecord(_is, handler);
        } else if (opName.equals("fnGetBookedFlightCount")) {
                return _invoke_fnGetBookedFlightCount(_is, handler);
        } else if (opName.equals("fnTransferFlightDetails")) {
                return _invoke_fnTransferFlightDetails(_is, handler);
        } else {
            throw new org.omg.CORBA.BAD_OPERATION(opName);
        }
    }

    // helper methods
    private org.omg.CORBA.portable.OutputStream _invoke_fnBookFlight(
            final org.omg.CORBA.portable.InputStream _is,
            final org.omg.CORBA.portable.ResponseHandler handler) {
        org.omg.CORBA.portable.OutputStream _output;
        String arg0_in = _is.read_string();
        String arg1_in = _is.read_string();
        String arg2_in = _is.read_string();
        String arg3_in = _is.read_string();
        String arg4_in = _is.read_string();
        String arg5_in = _is.read_string();
        String arg6_in = _is.read_string();
        String arg7_in = _is.read_string();

        String _arg_result = fnBookFlight(arg0_in, arg1_in, arg2_in, arg3_in, arg4_in, arg5_in, arg6_in, arg7_in);

        _output = handler.createReply();
        _output.write_string(_arg_result);

        return _output;
    }

    private org.omg.CORBA.portable.OutputStream _invoke_fnGetBookedFlightCount(
            final org.omg.CORBA.portable.InputStream _is,
            final org.omg.CORBA.portable.ResponseHandler handler) {
        org.omg.CORBA.portable.OutputStream _output;
        String arg0_in = _is.read_string();

        String _arg_result = fnGetBookedFlightCount(arg0_in);

        _output = handler.createReply();
        _output.write_string(_arg_result);

        return _output;
    }

    private org.omg.CORBA.portable.OutputStream _invoke_fnEditFlightRecord(
            final org.omg.CORBA.portable.InputStream _is,
            final org.omg.CORBA.portable.ResponseHandler handler) {
        org.omg.CORBA.portable.OutputStream _output;
        String arg0_in = _is.read_string();
        String arg1_in = _is.read_string();
        String arg2_in = _is.read_string();
        String arg3_in = _is.read_string();
        String arg4_in = _is.read_string();

        String _arg_result = fnEditFlightRecord(arg0_in, arg1_in, arg2_in, arg3_in, arg4_in);

        _output = handler.createReply();
        _output.write_string(_arg_result);

        return _output;
    }

    private org.omg.CORBA.portable.OutputStream _invoke_fnTransferFlightDetails(
            final org.omg.CORBA.portable.InputStream _is,
            final org.omg.CORBA.portable.ResponseHandler handler) {
        org.omg.CORBA.portable.OutputStream _output;
        String arg0_in = _is.read_string();
        String arg1_in = _is.read_string();
        String arg2_in = _is.read_string();

        String _arg_result = fnTransferFlightDetails(arg0_in, arg1_in, arg2_in);

        _output = handler.createReply();
        _output.write_string(_arg_result);

        return _output;
    }

    private org.omg.CORBA.portable.OutputStream _invoke_Createflights(
            final org.omg.CORBA.portable.InputStream _is,
            final org.omg.CORBA.portable.ResponseHandler handler) {
        org.omg.CORBA.portable.OutputStream _output;
        String arg0_in = _is.read_string();
        String arg1_in = _is.read_string();
        String arg2_in = _is.read_string();

        String _arg_result = Createflights(arg0_in, arg1_in, arg2_in);

        _output = handler.createReply();
        _output.write_string(_arg_result);

        return _output;
    }

}
