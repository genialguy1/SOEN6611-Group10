package FlightReservation;

/**
 * Interface definition: FlightReservationInterface.
 * 
 * @author OpenORB Compiler
 */
public interface FlightReservationInterfaceOperations
{
    /**
     * Operation fnBookFlight
     */
    public String fnBookFlight(String strCustomerFirstName, String strCustomerLastName, String strCustomerAddress, String dCustomerPhoneNumber, String strFlightSource, String strFlightDestination, String strFlightDate, String strFlightClass);

    /**
     * Operation fnGetBookedFlightCount
     */
    public String fnGetBookedFlightCount(String Location);

    /**
     * Operation fnEditFlightRecord
     */
    public String fnEditFlightRecord(String strManagerId, String strFlightId, String strFieldName, String strValue, String strOption);

    /**
     * Operation fnTransferFlightDetails
     */
    public String fnTransferFlightDetails(String strBookingID, String strNewSource, String strNewDate);

    /**
     * Operation Createflights
     */
    public String Createflights(String Fromloc, String to_loc, String Date);

}
